﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TGuide.Controllers
{
    public class AdminController : Controller
    {
        //
        // GET: /Admin/
        public ActionResult Main()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult Places()
        {
            return View();
        }
        public ActionResult Add()
        {
            return View();
        }
        public ActionResult Remove()
        {
            return View();
        }
        public ActionResult Edit()
        {
            return View();
        }
        public ActionResult GoEdit()
        {
            return View();
        }
    }
}